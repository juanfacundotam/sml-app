const postValidate = (req, res, next) => {
};

module.exports = postValidate;